import { getStore } from "@netlify/blobs";

const headers = {
  "Content-Type": "application/json; charset=utf-8",
  "Cache-Control": "no-store"
};

function json(data, status = 200) {
  return new Response(JSON.stringify(data), { status, headers });
}

function validItem(item) {
  return item && typeof item === "object" &&
    typeof item.id === "string" && item.id.length > 0 && item.id.length <= 100 &&
    typeof item.name === "string" && item.name.trim().length > 0 &&
    item.name.length <= 70 &&
    (item.price === null || item.price === "" ||
      (typeof item.price === "number" && Number.isFinite(item.price) && item.price >= 0));
}

export default async (request) => {
  try {
    const store = getStore("jmk-price-catalog");
    const url = new URL(request.url);

    if (request.method === "GET") {
      const listing = await store.list({ prefix: "items/" });
      const records = await Promise.all(
        listing.blobs.map(async ({ key }) => store.get(key, { type: "json" }))
      );
      const items = records.filter(Boolean);
      items.sort((a, b) => String(a.name).localeCompare(String(b.name), "es"));
      return json({ items });
    }

    if (request.method === "PUT") {
      const body = await request.json();
      const item = body?.item;
      if (!validItem(item)) return json({ error: "Datos del ítem inválidos" }, 400);
      await store.setJSON(`items/${item.id}`, {
        ...item,
        name: item.name.trim(),
        updatedAt: new Date().toISOString()
      });
      return json({ ok: true });
    }

    if (request.method === "DELETE") {
      const id = url.searchParams.get("id");
      if (!id || id.length > 100) return json({ error: "Falta el ID del ítem" }, 400);
      await store.delete(`items/${id}`);
      return json({ ok: true });
    }

    return json({ error: "Método no permitido" }, 405);
  } catch (error) {
    console.error("JMK PRICE storage error:", error);
    return json({ error: "No se pudo acceder al catálogo compartido" }, 500);
  }
};
